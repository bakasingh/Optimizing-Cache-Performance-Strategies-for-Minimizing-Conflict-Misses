See the Report and the necessary Information on following link:
https://docs.google.com/document/d/1HYeDVHUY2fbglDlCpkRiO0bEIB4GtVCI4Esoqqo5Uq0/edit?usp=sharing